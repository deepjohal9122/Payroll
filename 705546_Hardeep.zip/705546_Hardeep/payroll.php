<html>

<head>
    <title>Payrol management system</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <link rel="stylesheet" href="assets/css/main.css" />

</head>

<body>

    
    <div id="header">

        <div class="top">

            
            <div id="logo">
                <span class="image avatar48"><img src="images/avatar.jpg" alt="" /></span>
                <h1 id="title">Admin</h1>
     
            </div>

            <!-- Nav -->
            <nav id="nav">

                <ul>
                    <li><a href="#top" id="top-link" class="skel-layers-ignoreHref"><span class="icon fa-home">Home</span></a></li>
                    <li><a href="#portfolio" id="portfolio-link" class="skel-layers-ignoreHref"><span class="icon fa-user">Employee</span></a></li>
                    <li><a href="#about" id="about-link" class="skel-layers-ignoreHref"><span class="icon fa-th">list</span></a></li>
                    <li><a href="#contact" id="contact-link" class="skel-layers-ignoreHref">Pay Slip</a></li>
                </ul>
            </nav>

        </div>

    </div>

    <!-- Main -->
    <div id="main">

        <!-- Intro -->
        <section id="top" class="one dark cover" style="background-color:lightgrey";>
            <div class="container">

                <header>
                    <h2 class="alt"> <strong>Payroll Management System</strong> <br /> </h2>
                    <p>Insert/Update/Delete Operations</p>
                </header>

                <footer>
                    <a href="#portfolio" class="button scrolly">Employee</a>
                </footer>

            </div>
        </section>

        <!-- Portfolio -->
        <section id="portfolio" class="two">
            <div class="container">

                <header>
                    <h2>Employee</h2>
                </header>

                <p>You can add, update or delete employees record here.</p>

                <div class="row">
                    <div class="4u 12u$(mobile)">
                        <article class="item">
                            <a href="insert.php" class="image fit"><img src="images/pic02.png" alt="" /></a>
                            <header>
                                <h3>Insert</h3>
                            </header>
                        </article>

                    </div>
                    <div class="4u 12u$(mobile)">
                        <article class="item">
                            <a href="delete1.php" class="image fit"><img src="images/pic03.png" alt="" /></a>
                            <header>
                                <h3>Delete</h3>
                            </header>
                        </article>

                    </div>
                    <div class="4u$ 12u$(mobile)">
                        <article class="item">
                            <a href="edit1.php" class="image fit"><img src="images/pic04.png" alt="" /></a>
                            <header>
                                <h3>Update</h3>
                            </header>
                        </article>

                    </div>
                </div>

            </div>
        </section>

      

               

                

</body>

</html>